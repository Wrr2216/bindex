# @loganmct/lm-observability

Drop-in observability for Node/TypeScript projects:

- **Pushover notifications** — build start/success/failure, app startup/shutdown/crash
- **Wazuh alerts** — notifications and warning/error messages to a separate TCP/UDP syslog receiver
- **Syslog log shipping** — all logs forwarded to a syslog server via `winston-syslog`
- **CI/CD templates** — GitHub Actions workflow that builds, pushes to Docker Hub, and notifies Pushover

> No credentials are baked into this package. Both Pushover and syslog auto-disable unless you configure them (env var or `init()` override).

## Install

```bash
npm install ./vendor/loganmct-lm-observability-0.2.1.tgz
```

## Quick start

```ts
import { init } from "@loganmct/lm-observability";

const { logger, pushover } = init({
  appName: "my-service",
  appMeta: { version: process.env.APP_VERSION },
});

logger.info("server up", { port: 3000 });

// Manual notifications
await pushover.send({ message: "Backup complete" });
```

`init()` auto-registers signal handlers and sends an `appStarted` notification on boot, `appStopped` on SIGTERM/SIGINT, and `appCrashed` on uncaught exceptions / unhandled rejections.

## Config (env vars)

| Var                   | Default        | Purpose                                                  |
| --------------------- | -------------- | -------------------------------------------------------- |
| `APP_NAME`            | `unknown-app`  | App name (used as default notification title)            |
| `NODE_ENV`            | `development`  | Environment label                                        |
| `PUSHOVER_TOKEN`      | _(unset)_      | Pushover application token — **required to enable Pushover** |
| `PUSHOVER_USER`       | _(unset)_      | Pushover user/group key — **required to enable Pushover** |
| `PUSHOVER_DEVICE`     | _(unset)_      | Target a specific device (optional)                      |
| `PUSHOVER_ENABLED`    | auto           | Auto-disabled when token/user are empty; set `false` to force-off |
| `SYSLOG_HOST`         | _(unset)_      | Syslog server — **required to enable syslog shipping**   |
| `SYSLOG_PORT`         | `514`          | Syslog port                                              |
| `SYSLOG_PROTOCOL`     | `udp4`         | `udp4` / `tcp4` / `tls4`                                 |
| `SYSLOG_ENABLED`      | auto           | Auto-disabled when `SYSLOG_HOST` is empty; set `false` to force-off |
| `LOG_LEVEL`           | `info`         | Winston log level                                        |
| `CONSOLE_LOG_ENABLED` | `true`         | `false` disables console output                          |

## API

### `init(opts)`

Returns `{ config, logger, pushover }`. Overrides any env-var default.

```ts
init({
  appName: "api",
  pushover: { token: "azG...", user: "uQi...", device: "iphone" },
  syslog: { host: "10.0.0.5", protocol: "tcp4" },
  autoLifecycle: true,
  onShutdown: async () => { await db.close(); },
});
```

### `pushover` client

```ts
pushover.buildStart(version?)
pushover.buildSuccess(version?, durationMs?)
pushover.buildFailure(error, version?)
pushover.appStarted(meta?)
pushover.appStopped(reason?)
pushover.appCrashed(error)
pushover.send({ title, message, priority, sound, url, urlTitle })
```

Priorities are named `min | low | default | high | max` and map to Pushover's `-2..2`. `max` is Pushover's emergency priority — it re-alerts every 60s for up to an hour until acknowledged, so reserve it for things that must wake someone up.

### `logger`

Standard [Winston](https://github.com/winstonjs/winston) logger. Logs go to console (pretty) and syslog (RFC5424 JSON) when configured.

## CI/CD template

Copy `templates/docker-publish.yml` into `.github/workflows/` and `templates/notify/` into `.github/actions/notify/` in any project. It will:

1. Notify Pushover and Wazuh when build starts (each destination is independent)
2. Build the image
3. Push to `docker.io/<DOCKERHUB_USERNAME>/<repo-name>` with semver / sha / branch tags
4. Notify Pushover and Wazuh on success or failure, with the run URL and commit

**Required** GitHub repo variables (Settings → Secrets and variables → Actions → Variables):

- `DOCKERHUB_USERNAME`

**Required** GitHub repo secrets:

- `DOCKERHUB_TOKEN` — Docker Hub access token

**Optional** GitHub repo secrets:

- `PUSHOVER_TOKEN` — Pushover application token; omit to skip notifications
- `PUSHOVER_USER` — Pushover user key; required together with `PUSHOVER_TOKEN`

A starter `Dockerfile.example` is included in `templates/`. It deliberately sets no observability env vars — provide them via your orchestrator (Docker Compose, Dockge stack `.env`, Kubernetes ConfigMap, etc.).

## Migrating from 0.1.x (ntfy)

0.2.0 replaces ntfy with Pushover:

- `init()` now returns `pushover` instead of `ntfy`; `NtfyClient`/`NtfyMessage`/`NtfyPriority` are gone (`PushoverClient`/`PushoverMessage`/`PushoverPriority`).
- Env vars: `NTFY_URL`/`NTFY_TOPIC`/`NTFY_TOKEN` → `PUSHOVER_TOKEN`/`PUSHOVER_USER` (+ optional `PUSHOVER_DEVICE`).
- `send()` no longer takes `tags`/`click`/`actions`; use `sound`, `url`, `urlTitle`.
- Priority names are unchanged.

## Releasing this package

Tag a version and push:

```bash
npm version patch
git push --follow-tags
```

The bundled `.github/workflows/publish.yml` builds and publishes to npm with provenance. Requires `NPM_TOKEN` secret in the repo.

## Wazuh delivery (0.2.1)

Set `WAZUH_HOST=51.81.233.158`, `WAZUH_PORT=514`, and `WAZUH_PROTOCOL=tcp`.
Leave the host unset or set `WAZUH_ENABLED=false` to disable it. Wazuh is
independent of Pushover configuration and the existing SYSLOG destination.
`pushover.deliver(message)` returns `{ pushover: boolean, wazuh: boolean }`;
`pushover.send(message)` retains the existing `Promise<void>` interface.
Both destinations use bounded timeouts. See [alert setup](docs/alerting.md)
for the manager decoder/rules and CI runner source allowlist requirements.

To vendor this unreleased build: `npm ci && npm run build && npm pack`.
Copy the resulting tarball into each consumer's `vendor/` directory and update
its manifest and lockfile. Run `npm test` for isolated transport tests.
